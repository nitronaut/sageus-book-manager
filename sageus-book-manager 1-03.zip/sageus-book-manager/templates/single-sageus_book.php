<?php
/** Sageus single book template — theme can override by copying to sageus/single-book.php */
if (!defined('ABSPATH')) exit;
get_header();
$id = get_the_ID();
$author = sageus_get_book_meta($id,'author','');
$tagline = sageus_get_book_meta($id,'tagline','');
$excerpt = sageus_get_book_meta($id,'excerpt_text','');
$reviews = sageus_get_reviews($id);
$rating = sageus_get_average_rating($id);
$cover = sageus_get_cover_url($id,'large');
$genres_list = get_the_term_list($id, 'sageus_genre', '', ', ');
$tags_list = get_the_term_list($id, 'sageus_tag', '', ', ');
?>
<main class="sageus-single">
  <div class="sageus-single-inner">
    <p class="sageus-breadcrumb"><a href="<?php echo esc_url(get_post_type_archive_link('sageus_book')); ?>"><?php esc_html_e('← All Books','sageus-book-manager'); ?></a></p>
    <div class="sageus-hero">
      <div class="sageus-hero-cover">
        <?php if ($cover): ?><img src="<?php echo esc_url($cover); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" /><?php endif; ?>
      </div>
      <div class="sageus-hero-info">
        <h1><?php the_title(); ?></h1>
        <?php if ($author): ?><p class="sageus-author"><?php echo esc_html($author); ?></p><?php endif; ?>
        <?php if ($rating): ?><p><?php echo sageus_render_stars($rating); ?> <span><?php echo esc_html($rating); ?> / 5</span></p><?php endif; ?>
        <?php if ($tagline): ?><p class="sageus-tagline"><?php echo esc_html($tagline); ?></p><?php endif; ?>
        <ul class="sageus-meta-list">
          <?php if (sageus_format_pub_date($id)): ?><li><strong><?php esc_html_e('Published:','sageus-book-manager'); ?></strong> <?php echo esc_html(sageus_format_pub_date($id)); ?></li><?php endif; ?>
          <?php if (sageus_get_book_meta($id,'publisher','')): ?><li><strong><?php esc_html_e('Publisher:','sageus-book-manager'); ?></strong> <?php echo esc_html(sageus_get_book_meta($id,'publisher','')); ?></li><?php endif; ?>
          <?php if (sageus_get_book_meta($id,'isbn13','')): ?><li><strong>ISBN:</strong> <?php echo esc_html(sageus_get_book_meta($id,'isbn13','')); ?></li><?php endif; ?>
          <?php if (sageus_get_book_meta($id,'formats','')): ?><li><strong><?php esc_html_e('Formats:','sageus-book-manager'); ?></strong> <?php echo esc_html(sageus_get_book_meta($id,'formats','')); ?></li><?php endif; ?>
          <?php $series = get_the_terms($id,'sageus_series'); if ($series && !is_wp_error($series)): ?><li><strong><?php esc_html_e('Series:','sageus-book-manager'); ?></strong> <?php echo esc_html($series[0]->name); ?><?php if (sageus_get_series_position($id)): ?> — <?php printf(esc_html__('Book %d','sageus-book-manager'), sageus_get_series_position($id)); ?><?php endif; ?></li><?php endif; ?>
        </ul>
        <?php /* a] DETAILS — ABOVE Available at */ ?>
        <aside class="sageus-details-box" aria-label="<?php esc_attr_e('Book details','sageus-book-manager'); ?>">
          <h2 class="sageus-details-box-title"><?php esc_html_e('Details','sageus-book-manager'); ?></h2>
          <dl class="sageus-details-list">
            <?php if (sageus_format_pub_date($id)): ?><div class="sageus-details-row"><dt><?php esc_html_e('Published','sageus-book-manager'); ?></dt><dd><?php echo esc_html(sageus_format_pub_date($id)); ?></dd></div><?php endif; ?>
            <?php if ($genres_list): ?><div class="sageus-details-row"><dt><?php esc_html_e('Genres','sageus-book-manager'); ?></dt><dd><?php echo $genres_list; ?></dd></div><?php endif; ?>
            <?php if ($tags_list): ?><div class="sageus-details-row"><dt><?php esc_html_e('Tags','sageus-book-manager'); ?></dt><dd><?php echo $tags_list; ?></dd></div><?php endif; ?>
            <?php if (sageus_get_book_meta($id,'isbn13','') || sageus_get_book_meta($id,'isbn10','')): ?><div class="sageus-details-row"><dt><?php esc_html_e('ISBN','sageus-book-manager'); ?></dt><dd><?php echo esc_html(sageus_get_book_meta($id,'isbn13','') ?: sageus_get_book_meta($id,'isbn10','')); ?></dd></div><?php endif; ?>
            <?php if (sageus_get_book_meta($id,'publisher','')): ?><div class="sageus-details-row"><dt><?php esc_html_e('Publisher','sageus-book-manager'); ?></dt><dd><?php echo esc_html(sageus_get_book_meta($id,'publisher','')); ?></dd></div><?php endif; ?>
          </dl>
          <?php if (!$genres_list && !$tags_list && !sageus_format_pub_date($id)): ?><p class="description"><?php esc_html_e('Add a publication date, genres, and tags in the book editor to fill this box.','sageus-book-manager'); ?></p><?php endif; ?>
        </aside>
        <?php /* Available at — BELOW Details */ ?>
        <?php echo sageus_render_buy_buttons($id); ?>
      </div>
    </div>
    <div class="sageus-body">
      <?php if (get_the_content()): ?><h2><?php esc_html_e('About this book','sageus-book-manager'); ?></h2><div><?php the_content(); ?></div><?php endif; ?>
      <?php if ($excerpt): ?><h2><?php esc_html_e('Excerpt','sageus-book-manager'); ?></h2><blockquote class="sageus-excerpt"><?php echo wp_kses_post(wpautop($excerpt)); ?></blockquote><?php endif; ?>
      <?php if ($reviews): ?><h2><?php esc_html_e('Reviews','sageus-book-manager'); ?></h2><div class="sageus-reviews"><?php foreach ($reviews as $r): ?><blockquote class="sageus-review"><p>“<?php echo esc_html($r['quote']); ?>”</p><footer><?php if (!empty($r['rating'])) echo sageus_render_stars((float)$r['rating']); ?> — <?php echo esc_html(trim(($r['reviewer']??'').' '.($r['source'] ? '('.$r['source'].')' : ''))); ?><?php if (!empty($r['link'])): ?> <a href="<?php echo esc_url($r['link']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Read review','sageus-book-manager'); ?></a><?php endif; ?></footer></blockquote><?php endforeach; ?></div><?php endif; ?>
      <?php
      if (get_option('sageus_show_related','1')==='1' && $series && !is_wp_error($series)) {
        $siblings = new WP_Query(['post_type'=>'sageus_book','post_status'=>'publish','posts_per_page'=>-1,'tax_query'=>[['taxonomy'=>'sageus_series','field'=>'term_id','terms'=>$series[0]->term_id]],'post__not_in'=>[$id],'orderby'=>'meta_value_num','meta_key'=>'_sageus_series_position','order'=>'ASC']);
        if ($siblings->have_posts()) { echo '<h2>'.esc_html__('Also in this series','sageus-book-manager').'</h2>'; echo Sageus_Grids::cards($siblings->posts, 4); }
        wp_reset_postdata();
      }
      ?>
    </div>
  </div>
</main>
<?php get_footer(); ?>
