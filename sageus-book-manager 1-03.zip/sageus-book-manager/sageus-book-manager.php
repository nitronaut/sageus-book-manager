<?php
/**
 * Plugin Name:       Sageus Book Manager
 * Plugin URI:        https://sageus.com/book-manager
 * Description:       An easy-to-use system for authors to add books to their WordPress websites. Add books with a form, link to any retailer, show grids anywhere, and feature books in widgets.
 * Version:           1.0.3
 * Requires at least: 6.2
 * Requires PHP:      8.0
 * Author:            Sageus
 * Author URI:        https://sageus.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sageus-book-manager
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) exit;

define('SAGEUS_VERSION', '1.0.3');
define('SAGEUS_PATH', plugin_dir_path(__FILE__));
define('SAGEUS_URL', plugin_dir_url(__FILE__));
define('SAGEUS_BASENAME', plugin_basename(__FILE__));

// FIX 1 — Featured Image / Media Library:
// Many themes don't declare post-thumbnails, which hides the Featured Image box.
// The plugin now declares it itself. We also force the Classic Editor for Books/Grids
// because Gutenberg saves via REST and drops classic $_POST meta-box data (buy links,
// reviews, cover) — that was why retailer links appeared not to save.
add_action('after_setup_theme', function() {
    add_theme_support('post-thumbnails');
    add_theme_support('post-thumbnails', ['sageus_book']);
});
add_filter('use_block_editor_for_post_type', function($use, $post_type) {
    if (in_array($post_type, ['sageus_book','sageus_grid'], true)) return false;
    return $use;
}, 10, 2);

require_once SAGEUS_PATH . 'includes/class-sageus-cpt.php';
require_once SAGEUS_PATH . 'includes/class-sageus-meta.php';
require_once SAGEUS_PATH . 'includes/class-sageus-retailers.php';
require_once SAGEUS_PATH . 'includes/class-sageus-grids.php';
require_once SAGEUS_PATH . 'includes/class-sageus-shortcodes.php';
require_once SAGEUS_PATH . 'includes/class-sageus-widget.php';
require_once SAGEUS_PATH . 'includes/class-sageus-templates.php';
require_once SAGEUS_PATH . 'includes/class-sageus-settings.php';
require_once SAGEUS_PATH . 'includes/class-sageus-blocks.php';
require_once SAGEUS_PATH . 'includes/helpers.php';

function sageus_init() {
    load_plugin_textdomain('sageus-book-manager', false, dirname(SAGEUS_BASENAME) . '/languages');
    Sageus_CPT::init();
    Sageus_Meta::init();
    Sageus_Retailers::init();
    Sageus_Grids::init();
    Sageus_Shortcodes::init();
    Sageus_Widget::init();
    Sageus_Templates::init();
    Sageus_Settings::init();
    Sageus_Blocks::init();
}
add_action('plugins_loaded', 'sageus_init');

function sageus_activate() {
    // Register CPTs/taxonomies before flushing so rewrite rules include them.
    Sageus_CPT::register_all();
    Sageus_Retailers::maybe_seed_defaults();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'sageus_activate');

function sageus_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'sageus_deactivate');

function sageus_enqueue_front() {
    if (!is_admin()) {
        wp_enqueue_style('sageus-book-manager', SAGEUS_URL . 'assets/css/sageus.css', [], SAGEUS_VERSION);
    }
}
add_action('wp_enqueue_scripts', 'sageus_enqueue_front');

function sageus_enqueue_admin($hook) {
    $screen = get_current_screen();
    // Enqueue on post edit, post-new, and our settings/retailers pages — regardless of hook name.
    $is_sageus_edit = ($hook === 'post.php' || $hook === 'post-new.php' || $hook === 'edit.php') && $screen && in_array($screen->post_type, ['sageus_book','sageus_grid'], true);
    $is_sageus_page = in_array($hook, ['sageus_book_page_sageus-settings','sageus_book_page_sageus-retailers'], true);
    if ($is_sageus_edit || $is_sageus_page) {
        wp_enqueue_style('sageus-admin', SAGEUS_URL . 'assets/css/admin.css', [], SAGEUS_VERSION);
        // Vanilla JS — no jQuery dependency, so a jQuery conflict can't break the Media Library or repeaters.
        wp_enqueue_script('sageus-admin', SAGEUS_URL . 'assets/js/admin.js', [], SAGEUS_VERSION, true);
        wp_enqueue_media(); // <-- ensures wp.media is available for Featured Image + Cover button
        wp_enqueue_script('media-upload');
        wp_enqueue_script('thickbox');
        wp_enqueue_style('thickbox');
    }
    if ($hook === 'sageus_book_page_sageus-settings' || $hook === 'sageus_book_page_sageus-retailers') {
        wp_enqueue_style('sageus-admin', SAGEUS_URL . 'assets/css/admin.css', [], SAGEUS_VERSION);
        wp_enqueue_media();
    }
}
add_action('admin_enqueue_scripts', 'sageus_enqueue_admin');
