// Sageus Admin — vanilla JS, no jQuery. Fixes: Media Library, Buy Links, Reviews, Retailers, Grid fields.
document.addEventListener('DOMContentLoaded', function() {
  // ---------- Grid: show/hide taxonomy / specific pickers ----------
  var sel = document.getElementById('sageus-grid-selection');
  function toggleGrid() {
    if (!sel) return;
    var v = sel.value;
    document.querySelectorAll('.sageus-grid-tax, .sageus-grid-specific').forEach(function(el){ el.style.display='none'; });
    if (['genre','series','tag'].indexOf(v) !== -1) {
      var taxEl = document.querySelector('.sageus-grid-tax-' + v);
      if (taxEl) taxEl.style.display = 'block';
    }
    if (v === 'specific') {
      var sp = document.querySelector('.sageus-grid-specific');
      if (sp) sp.style.display = 'block';
    }
  }
  if (sel) { sel.addEventListener('change', toggleGrid); toggleGrid(); }

  // ---------- Cover: Media Library ----------
  var setCoverBtn = document.getElementById('sageus-set-cover');
  var removeCoverBtn = document.getElementById('sageus-remove-cover');
  var coverInput = document.getElementById('sageus-cover-id');
  var coverPreview = document.getElementById('sageus-cover-preview');
  if (setCoverBtn && typeof wp !== 'undefined' && wp.media) {
    setCoverBtn.addEventListener('click', function(e) {
      e.preventDefault();
      var frame = wp.media({ title: 'Choose Book Cover', button: { text: 'Use as Cover' }, multiple: false, library: { type: 'image' } });
      frame.on('select', function() {
        var att = frame.state().get('selection').first().toJSON();
        if (coverInput) coverInput.value = att.id;
        if (coverPreview) { coverPreview.src = att.url; coverPreview.style.display = 'block'; }
        // Also update the WP Featured Image preview if present, so both stay in sync.
        var featImg = document.querySelector('#postimagediv .inside img');
        if (featImg) { featImg.src = att.url; }
      });
      frame.open();
    });
  } else if (setCoverBtn) {
    // Fallback: if wp.media failed to load, tell the user instead of silently doing nothing.
    setCoverBtn.addEventListener('click', function(e){ e.preventDefault(); alert('Media Library could not load. Please reload the page and try again, or use “Set featured image” in the Featured Image box.'); });
  }
  if (removeCoverBtn) {
    removeCoverBtn.addEventListener('click', function(e){
      e.preventDefault();
      if (coverInput) coverInput.value = '';
      if (coverPreview) { coverPreview.src=''; coverPreview.style.display='none'; }
    });
  }

  // ---------- Buy Links repeater — uses <template>, reindexes correctly ----------
  var addBuy = document.getElementById('sageus-add-buy');
  var buyWrap = document.getElementById('sageus-buy-repeater');
  var buyTpl = document.getElementById('sageus-buy-template');
  function reindexBuy() {
    if (!buyWrap) return;
    buyWrap.querySelectorAll('.sageus-buy-row').forEach(function(row, idx){
      row.querySelectorAll('input, select').forEach(function(inp){
        var name = inp.getAttribute('name') || '';
        inp.setAttribute('name', name.replace(/sageus_buy\[\d+\]/, 'sageus_buy['+idx+']').replace(/sageus_buy\[__INDEX__\]/, 'sageus_buy['+idx+']'));
      });
    });
  }
  if (addBuy && buyWrap && buyTpl) {
    addBuy.addEventListener('click', function(){
      var html = buyTpl.innerHTML.replaceAll('__INDEX__', String(buyWrap.querySelectorAll('.sageus-buy-row').length));
      var tmp = document.createElement('div'); tmp.innerHTML = html.trim();
      buyWrap.appendChild(tmp.firstElementChild);
      reindexBuy();
    });
  }
  document.addEventListener('click', function(e){
    var btn = e.target.closest && e.target.closest('.sageus-remove-buy');
    if (btn) {
      var rows = buyWrap ? buyWrap.querySelectorAll('.sageus-buy-row') : [];
      if (rows.length > 1) { btn.closest('.sageus-buy-row').remove(); reindexBuy(); }
      else {
        // Last row: clear it instead of removing, so save still submits an empty row (which is ignored).
        var r = btn.closest('.sageus-buy-row');
        r.querySelectorAll('input').forEach(function(i){ i.value=''; });
        var s = r.querySelector('select'); if (s) s.selectedIndex = 0;
      }
    }
    var rbtn = e.target.closest && e.target.closest('.sageus-remove-review');
    if (rbtn) {
      var wrap = document.getElementById('sageus-reviews-repeater');
      var rrows = wrap ? wrap.querySelectorAll('.sageus-review-row') : [];
      if (rrows.length > 1) rbtn.closest('.sageus-review-row').remove();
      else { var rr = rbtn.closest('.sageus-review-row'); rr.querySelectorAll('input, textarea').forEach(function(i){ i.value=''; }); }
    }
  });

  // ---------- Reviews repeater ----------
  var addReview = document.getElementById('sageus-add-review');
  var revWrap = document.getElementById('sageus-reviews-repeater');
  if (addReview && revWrap) {
    addReview.addEventListener('click', function(){
      var first = revWrap.querySelector('.sageus-review-row');
      if (!first) return;
      var clone = first.cloneNode(true);
      var idx = revWrap.querySelectorAll('.sageus-review-row').length;
      clone.querySelectorAll('input, textarea, select').forEach(function(inp){
        var n = inp.getAttribute('name') || '';
        inp.setAttribute('name', n.replace(/\[\d+\]/, '['+idx+']'));
        if (inp.tagName !== 'SELECT') inp.value = '';
        else inp.selectedIndex = 0;
      });
      revWrap.appendChild(clone);
    });
  }

  // ---------- Retailers page ----------
  var addRetailer = document.getElementById('sageus-add-retailer');
  var retBody = document.getElementById('sageus-retailers-tbody');
  if (addRetailer && retBody) {
    addRetailer.addEventListener('click', function(){
      var k = 'new-' + Date.now();
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td><input type="text" name="retailers['+k+'][name]" placeholder="Retailer name" style="width:100%" /></td>' +
        '<td><input type="color" name="retailers['+k+'][color]" value="#2A6B7A" /></td>' +
        '<td><input type="text" name="retailers['+k+'][image]" placeholder="https://…/button.png" style="width:100%" /></td>' +
        '<td><button type="button" class="button sageus-remove-retailer">Remove</button></td>';
      retBody.appendChild(tr);
    });
    retBody.addEventListener('click', function(e){
      var b = e.target.closest && e.target.closest('.sageus-remove-retailer');
      if (b) b.closest('tr').remove();
    });
  }
});
