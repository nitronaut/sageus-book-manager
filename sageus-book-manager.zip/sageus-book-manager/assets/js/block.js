// Sageus Book Grid block — server-side rendered. Picker lives in Inspector via PHP fallback if needed.
// This file registers a minimal block that prompts for a Grid ID; full picker UI can be extended here.
(function(){
  if (typeof wp === 'undefined' || !wp.blocks) return;
  var el = wp.element.createElement;
  var TextControl = wp.components.TextControl;
  wp.blocks.registerBlockType('sageus/book-grid', {
    title: 'Sageus Book Grid',
    icon: 'book-alt',
    category: 'widgets',
    attributes: { gridId: { type: 'number', default: 0 }, cols: { type: 'number', default: 3 } },
    edit: function(props){
      return el('div', {className:'sageus-block-edit'},
        el('p', null, 'Sageus Book Grid'),
        el(TextControl, { label:'Grid ID (find it in Book Grids → All Grids)', value: String(props.attributes.gridId||''), onChange: function(v){ props.setAttributes({gridId: parseInt(v)||0}); } }),
        el(TextControl, { label:'Columns', value: String(props.attributes.cols||3), onChange: function(v){ props.setAttributes({cols: parseInt(v)||3}); } }),
        el('p', {className:'description'}, 'Tip: Use the shortcode [sageus_grid id="123"] in any page if you prefer.')
      );
    },
    save: function(){ return null; }
  });
})();
