<?php
if (!defined('ABSPATH')) exit;
class Sageus_Settings {
    public static function init() {
        add_action('admin_menu', [__CLASS__,'menu']);
        add_action('admin_init', [__CLASS__,'register']);
        add_action('admin_post_sageus_export', [__CLASS__,'export']);
        add_action('admin_post_sageus_import', [__CLASS__,'import']);
    }
    public static function menu(){ add_submenu_page('edit.php?post_type=sageus_book','Settings','Settings','manage_options','sageus-settings',[__CLASS__,'page']); }
    public static function register(){
        foreach ([
            'sageus_book_slug'=>['default'=>'books'],
            'sageus_open_new_tab'=>['default'=>'1'],
            'sageus_affiliate_disclosure'=>['default'=>'As an affiliate, we may earn a commission on purchases made via these links.'],
            'sageus_jsonld'=>['default'=>'1'],
            'sageus_show_related'=>['default'=>'1'],
        ] as $k=>$v) register_setting('sageus_settings', $k);
    }
    public static function page(){
        echo '<div class="wrap"><h1>Sageus Book Manager — Settings</h1><form method="post" action="options.php">'; settings_fields('sageus_settings'); do_settings_sections('sageus_settings');
        echo '<table class="form-table">';
        $rows = [
            ['sageus_book_slug','Book URL slug','books','Text — e.g. books. Re-save Permalinks after changing.'],
            ['sageus_affiliate_disclosure','Affiliate disclosure','As an affiliate, we may earn a commission on purchases made via these links.','Shown under Buy buttons if set.'],
        ];
        foreach ($rows as [$key,$label,$ph,$desc]) { echo '<tr><th>'.esc_html($label).'</th><td><input type="text" name="'.esc_attr($key).'" value="'.esc_attr(get_option($key,$ph)).'" class="regular-text" /><p class="description">'.esc_html($desc).'</p></td></tr>'; }
        foreach ([['sageus_open_new_tab','Open retailer links in a new tab'],['sageus_jsonld','Output Book JSON-LD structured data'],['sageus_show_related','Show related books on single book pages']] as [$key,$label]) {
            echo '<tr><th>'.esc_html($label).'</th><td><input type="checkbox" name="'.esc_attr($key).'" value="1" '.checked(get_option($key,'1'),'1',false).' /></td></tr>';
        }
        echo '</table>'; submit_button(); echo '</form>';
        echo '<hr><h2>Import / Export</h2><p><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=sageus_export'),'sageus_export')).'">Export Books (CSV)</a></p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data"><input type="hidden" name="action" value="sageus_import" />'.wp_nonce_field('sageus_import').'<p><input type="file" name="sageus_csv" accept=".csv" required /> <input type="submit" class="button" value="Import CSV" /></p><p class="description">CSV columns: title, author, tagline, pub_date (YYYY-MM-DD), isbn13, publisher, status, genre, series, series_position, buy_url_1, buy_retailer_1 …</p></form>';
        echo '<p><strong>Getting Started:</strong> Books → Add New to add a book. Book Grids → Add New to create a grid, copy its shortcode, and paste it into any page. Appearance → Widgets to add the Sageus Book Widget.</p></div>';
    }
    public static function export(){
        if (!current_user_can('manage_options') || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')), 'sageus_export')) wp_die('Unauthorized');
        header('Content-Type: text/csv'); header('Content-Disposition: attachment; filename=sageus-books.csv');
        $out = fopen('php://output','w'); fputcsv($out, ['title','author','tagline','pub_date','isbn13','publisher','status','genre','series','series_position']);
        foreach (get_posts(['post_type'=>'sageus_book','posts_per_page'=>-1]) as $p) {
            $g = get_the_terms($p->ID,'sageus_genre'); $s = get_the_terms($p->ID,'sageus_series');
            fputcsv($out, [$p->post_title, sageus_get_book_meta($p->ID,'author',''), sageus_get_book_meta($p->ID,'tagline',''), sageus_get_pub_date($p->ID), sageus_get_book_meta($p->ID,'isbn13',''), sageus_get_book_meta($p->ID,'publisher',''), sageus_book_status($p->ID), $g && !is_wp_error($g) ? $g[0]->name : '', $s && !is_wp_error($s) ? $s[0]->name : '', sageus_get_series_position($p->ID)]);
        }
        fclose($out); exit;
    }
    public static function import(){
        if (!current_user_can('manage_options') || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce']??'')), 'sageus_import')) wp_die('Unauthorized');
        if (empty($_FILES['sageus_csv']['tmp_name'])) wp_die('No file.');
        $fh = fopen(sanitize_text_field($_FILES['sageus_csv']['tmp_name']), 'r');
        $header = fgetcsv($fh); $count=0;
        while (($row = fgetcsv($fh)) !== false) {
            $d = array_combine($header, $row); if (empty($d['title'])) continue;
            $id = wp_insert_post(['post_type'=>'sageus_book','post_title'=>sanitize_text_field($d['title']),'post_status'=>'publish']);
            if (is_wp_error($id)) continue;
            foreach (['author','tagline','pub_date','isbn13','publisher','status'] as $f) if (isset($d[$f])) update_post_meta($id,'_sageus_'.$f, sanitize_text_field($d[$f]));
            if (!empty($d['genre'])) wp_set_object_terms($id, sanitize_text_field($d['genre']), 'sageus_genre', true);
            if (!empty($d['series'])) wp_set_object_terms($id, sanitize_text_field($d['series']), 'sageus_series', true);
            if (isset($d['series_position'])) update_post_meta($id,'_sageus_series_position', (int)$d['series_position']);
            $count++;
        }
        fclose($fh);
        wp_redirect(admin_url('edit.php?post_type=sageus_book&sageus_imported='.$count)); exit;
    }
}
