<?php
if (!defined('ABSPATH')) exit;
class Sageus_Grids {
    public static function init() {
        add_filter('manage_sageus_grid_posts_columns', [__CLASS__,'cols']);
        add_action('manage_sageus_grid_posts_custom_column', [__CLASS__,'col'], 10, 2);
    }
    public static function cols($c){ $c['shortcode']='Shortcode'; $c['selection']='Selection'; return $c; }
    public static function col($col,$id){ if($col==='shortcode') echo '<code>[sageus_grid id="'.$id.'"]</code>'; if($col==='selection') echo esc_html(get_post_meta($id,'_sageus_grid_selection',true) ?: 'all'); }
    public static function get_config($grid_id) {
        $sel = get_post_meta($grid_id,'_sageus_grid_selection',true) ?: 'all';
        $val = '';
        if (in_array($sel,['genre','series','tag'])) $val = get_post_meta($grid_id,'_sageus_grid_tax_'.$sel,true);
        if ($sel==='specific') $val = get_post_meta($grid_id,'_sageus_grid_specific',true);
        return [
            'selection'=>$sel,'value'=>$val,
            'grouping'=> get_post_meta($grid_id,'_sageus_grid_grouping',true) ?: 'none',
            'sort'=> get_post_meta($grid_id,'_sageus_grid_sort',true) ?: 'pub_date_desc',
            'cols'=> (int)(get_post_meta($grid_id,'_sageus_grid_cols',true) ?: 3),
            'limit'=> (int)(get_post_meta($grid_id,'_sageus_grid_limit',true) ?: 0),
            'empty'=> get_post_meta($grid_id,'_sageus_grid_empty',true) ?: __('More books coming soon.','sageus-book-manager'),
        ];
    }
    public static function render_grid($grid_id, $atts=[]) {
        $cfg = self::get_config($grid_id);
        $cols = isset($atts['cols']) ? (int)$atts['cols'] : $cfg['cols'];
        $limit = isset($atts['limit']) ? (int)$atts['limit'] : $cfg['limit'];
        $limit = $limit > 0 ? $limit : -1;
        $args = sageus_get_books_query_args($cfg['selection'], $cfg['value'], $cfg['sort'], $limit);
        $q = new WP_Query($args);
        if (!$q->have_posts()) return '<p class="sageus-empty">'.esc_html($cfg['empty']).'</p>';
        $out = '';
        if ($cfg['grouping'] !== 'none') {
            $groups = [];
            foreach ($q->posts as $p) {
                $key = __('Uncategorized','sageus-book-manager');
                if ($cfg['grouping']==='genre') { $t=get_the_terms($p->ID,'sageus_genre'); $key = $t && !is_wp_error($t) ? $t[0]->name : $key; }
                if ($cfg['grouping']==='series') { $t=get_the_terms($p->ID,'sageus_series'); $key = $t && !is_wp_error($t) ? $t[0]->name : $key; }
                if ($cfg['grouping']==='tag') { $t=get_the_terms($p->ID,'sageus_tag'); $key = $t && !is_wp_error($t) ? $t[0]->name : $key; }
                if ($cfg['grouping']==='status') $key = ucwords(str_replace('_',' ', sageus_book_status($p->ID)));
                $groups[$key][] = $p;
            }
            foreach ($groups as $label=>$posts) {
                $out .= '<h3 class="sageus-group-title">'.esc_html($label).'</h3>';
                $out .= self::cards($posts, $cols);
            }
        } else {
            $out .= self::cards($q->posts, $cols);
        }
        wp_reset_postdata();
        return $out;
    }
    public static function cards($posts, $cols) {
        $cols = max(1,min(6,$cols));
        $out = '<div class="sageus-grid sageus-cols-'.$cols.'">';
        foreach ($posts as $p) {
            $cover = sageus_get_cover_url($p->ID,'medium');
            $author = sageus_get_book_meta($p->ID,'author','');
            $tagline = sageus_get_book_meta($p->ID,'tagline','');
            $out .= '<article class="sageus-card"><a href="'.esc_url(get_permalink($p->ID)).'" class="sageus-card-link">';
            if ($cover) $out .= '<div class="sageus-card-cover"><img src="'.esc_url($cover).'" alt="'.esc_attr($p->post_title).'" loading="lazy" /></div>';
            else $out .= '<div class="sageus-card-cover sageus-no-cover"><span>'.esc_html($p->post_title).'</span></div>';
            $out .= '<h3 class="sageus-card-title">'.esc_html($p->post_title).'</h3>';
            if ($author) $out .= '<p class="sageus-card-author">'.esc_html($author).'</p>';
            if ($tagline) $out .= '<p class="sageus-card-tagline">'.esc_html(wp_trim_words($tagline,18)).'</p>';
            $pub = sageus_format_pub_date($p->ID);
            if ($pub) $out .= '<p class="sageus-card-date">'.esc_html($pub).'</p>';
            $status = sageus_book_status($p->ID);
            if ($status==='coming_soon') $out .= '<span class="sageus-badge sageus-badge-soon">'.esc_html__('Coming Soon','sageus-book-manager').'</span>';
            $out .= '</a></article>';
        }
        $out .= '</div>';
        return $out;
    }
}
