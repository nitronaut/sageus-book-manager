<?php
if (!defined('ABSPATH')) exit;
class Sageus_Retailers {
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
    }
    public static function defaults() {
        return [
            'amazon' => ['name'=>'Amazon','color'=>'#FF9900','image'=>''],
            'barnes-noble' => ['name'=>'Barnes & Noble','color'=>'#2E5939','image'=>''],
            'apple-books' => ['name'=>'Apple Books','color'=>'#000000','image'=>''],
            'kobo' => ['name'=>'Kobo','color'=>'#BF0000','image'=>''],
            'google-play' => ['name'=>'Google Play Books','color'=>'#1A73E8','image'=>''],
            'bookshop' => ['name'=>'Bookshop.org','color'=>'#2A6B7A','image'=>''],
            'indiebound' => ['name'=>'IndieBound','color'=>'#6B3FA0','image'=>''],
        ];
    }
    public static function get_all() {
        $saved = get_option('sageus_retailers', []);
        if (empty($saved) || !is_array($saved)) return self::defaults();
        return $saved;
    }
    public static function maybe_seed_defaults() {
        if (false === get_option('sageus_retailers')) update_option('sageus_retailers', self::defaults());
    }
    public static function menu() {
        add_submenu_page('edit.php?post_type=sageus_book', 'Retailers', 'Retailers', 'manage_options', 'sageus-retailers', [__CLASS__, 'page']);
    }
    public static function page() {
        if (isset($_POST['sageus_retailers_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sageus_retailers_nonce'])), 'sageus_retailers_save')) {
            $in = isset($_POST['retailers']) ? wp_unslash($_POST['retailers']) : [];
            $out = [];
            foreach ((array)$in as $slug=>$r) {
                if (empty($r['name'])) continue;
                $key = sanitize_title($r['name']);
                if (!$key) $key = sanitize_title($slug);
                $out[$key] = ['name'=>sanitize_text_field($r['name']),'color'=>sanitize_hex_color($r['color']??'') ?: '#2A6B7A','image'=>esc_url_raw($r['image']??'')];
            }
            update_option('sageus_retailers', $out);
            echo '<div class="updated"><p>Retailers saved.</p></div>';
        }
        if (isset($_GET['reset']) && current_user_can('manage_options')) { update_option('sageus_retailers', self::defaults()); echo '<div class="updated"><p>Reset to 7 default retailers.</p></div>'; }
        $retailers = self::get_all();
        echo '<div class="wrap"><h1>Sageus Retailers</h1><p>These buttons appear on every book page. Add as many retailers as you want, upload a custom button image, or change the button colour. Existing book links keep working even if you rename a retailer slug.</p>';
        echo '<form method="post">'; wp_nonce_field('sageus_retailers_save','sageus_retailers_nonce');
        echo '<table class="widefat"><thead><tr><th>Name</th><th>Button Colour</th><th>Button Image URL (optional)</th><th></th></tr></thead><tbody id="sageus-retailers-tbody">';
        foreach ($retailers as $slug=>$r) {
            echo '<tr><td><input type="text" name="retailers['.esc_attr($slug).'][name]" value="'.esc_attr($r['name']).'" style="width:100%" /></td>';
            echo '<td><input type="color" name="retailers['.esc_attr($slug).'][color]" value="'.esc_attr($r['color']??'#2A6B7A').'" /></td>';
            echo '<td><input type="text" name="retailers['.esc_attr($slug).'][image]" value="'.esc_attr($r['image']??'').'" placeholder="https://…/button.png" style="width:100%" /></td>';
            echo '<td><button type="button" class="button sageus-remove-retailer">Remove</button></td></tr>';
        }
        echo '</tbody></table>';
        echo '<p><button type="button" class="button" id="sageus-add-retailer">+ Add Retailer</button> <a class="button" href="'.esc_url(admin_url('edit.php?post_type=sageus_book&page=sageus-retailers&reset=1')).'">Reset to 7 Defaults</a></p>';
        echo '<p><input type="submit" class="button-primary" value="Save Retailers" /></p></form>';
        echo '<h2>How it works</h2><p>On each book, choose a retailer and paste the purchase URL — your affiliate link is kept exactly as pasted. You can add unlimited links per book.</p></div>';
        // Add Retailer button is handled in assets/js/admin.js (sageus-retailers page) — no fragile inline JS here.
        echo '<p class="description">Click “+ Add Retailer”, fill in the name, choose a colour, optionally paste a button image URL, then click <strong>Save Retailers</strong>. The new retailer will immediately appear in every book’s Purchase Links dropdown.</p>';
    }
}
