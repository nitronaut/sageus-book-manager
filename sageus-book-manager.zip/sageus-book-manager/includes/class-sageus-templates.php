<?php
if (!defined('ABSPATH')) exit;
class Sageus_Templates {
    public static function init() {
        add_filter('template_include', [__CLASS__,'single_template']);
        add_filter('the_content', [__CLASS__,'maybe_append_book_content']);
        add_action('wp_head', [__CLASS__,'seo_head']);
    }
    public static function single_template($tpl) {
        if (is_singular('sageus_book')) {
            $theme_tpl = locate_template(['sageus/single-book.php','single-sageus_book.php']);
            if ($theme_tpl) return $theme_tpl;
            return SAGEUS_PATH . 'templates/single-sageus_book.php';
        }
        return $tpl;
    }
    // If theme template is used via template_include we don't need content filter; this only helps when theme forces its own single.php
    public static function maybe_append_book_content($content) {
        return $content;
    }
    public static function seo_head() {
        if (!is_singular('sageus_book')) return;
        $id = get_the_ID();
        $cover = sageus_get_cover_url($id,'large');
        if ($cover) echo '<meta property="og:image" content="'.esc_url($cover).'" />'."\n";
        echo '<meta property="og:type" content="book" />'."\n";
        if (get_option('sageus_jsonld','1')==='1') {
            $data = ['@context'=>'https://schema.org','@type'=>'Book','name'=>get_the_title($id),'author'=>['@type'=>'Person','name'=>sageus_get_book_meta($id,'author','')],'image'=>$cover,'datePublished'=>sageus_get_pub_date($id),'isbn'=>sageus_get_book_meta($id,'isbn13','') ?: sageus_get_book_meta($id,'isbn10',''),'publisher'=>sageus_get_book_meta($id,'publisher',''),'description'=>sageus_get_book_meta($id,'tagline','')];
            $links = sageus_get_buy_links($id);
            if ($links) $data['offers'] = array_map(fn($l)=>['@type'=>'Offer','url'=>$l['url']], $links);
            echo '<script type="application/ld+json">'.wp_json_encode(array_filter($data)).'</script>'."\n";
        }
    }
}
