<?php
if (!defined('ABSPATH')) exit;
class Sageus_Meta {
    public static function init() {
        add_action('init', [__CLASS__, 'register_meta']);
        add_action('add_meta_boxes', [__CLASS__,'boxes']);
        add_action('save_post_sageus_book', [__CLASS__,'save'], 10, 2);
        add_action('save_post_sageus_grid', [__CLASS__,'save_grid'], 10, 2);
    }
    public static function register_meta() {
        // Makes fields visible / savable via REST as well, so Gutenberg / API clients don't silently drop them.
        $fields = ['author','tagline','pub_date','isbn13','isbn10','publisher','language','page_count','series_position','formats','sample_url','goodreads_url','bookbub_url','awards','status','excerpt_text','cover_id','cover_url','featured'];
        foreach ($fields as $f) {
            register_post_meta('sageus_book', '_sageus_'.$f, ['show_in_rest'=>true,'single'=>true,'type'=>'string','auth_callback'=>function(){ return current_user_can('edit_posts'); }]);
        }
        register_post_meta('sageus_book', '_sageus_buy_links', ['show_in_rest'=>['schema'=>['type'=>'array','items'=>['type'=>'object','properties'=>['retailer'=>['type'=>'string'],'url'=>['type'=>'string'],'label'=>['type'=>'string'],'format'=>['type'=>'string']]]]],'single'=>true,'type'=>'array','auth_callback'=>function(){ return current_user_can('edit_posts'); }]);
        register_post_meta('sageus_book', '_sageus_reviews', ['show_in_rest'=>true,'single'=>true,'type'=>'array','auth_callback'=>function(){ return current_user_can('edit_posts'); }]);
    }
    public static function boxes() {
        // FIX — Cover box in the sidebar, next to Featured Image, using wp.media directly.
        // If Featured Image is hidden/broken by the theme, this still works.
        add_meta_box('sageus_cover','Book Cover (Media Library)',[__CLASS__,'render_cover'],'sageus_book','side','high');
        // NEW — Published / Genres / Tags summary box (also on front-end, see template)
        add_meta_box('sageus_summary','Published  •  Genres  •  Tags',[__CLASS__,'render_summary'],'sageus_book','side','high');
        add_meta_box('sageus_details','Book Details',[__CLASS__,'render_details'],'sageus_book','normal','high');
        add_meta_box('sageus_buy','Purchase Links (Retailers)',[__CLASS__,'render_buy'],'sageus_book','normal','high');
        add_meta_box('sageus_reviews','Reviews',[__CLASS__,'render_reviews'],'sageus_book','normal','default');
        add_meta_box('sageus_grid_settings','Book Grid Settings',[__CLASS__,'render_grid'],'sageus_grid','normal','high');
        add_meta_box('sageus_grid_shortcode','Shortcode',[__CLASS__,'render_grid_shortcode'],'sageus_grid','side','high');
    }
    private static function field($label,$name,$value,$type='text',$placeholder='') {
        echo '<p><label><strong>'.esc_html($label).'</strong><br>';
        if ($type==='textarea') echo '<textarea name="sageus['.esc_attr($name).']" rows="3" style="width:100%">'.esc_textarea($value).'</textarea>';
        elseif ($type==='date') echo '<input type="date" name="sageus['.esc_attr($name).']" value="'.esc_attr($value).'" />';
        elseif ($type==='number') echo '<input type="number" name="sageus['.esc_attr($name).']" value="'.esc_attr($value).'" style="width:100px" />';
        elseif ($type==='checkbox') echo '<input type="checkbox" name="sageus['.esc_attr($name).']" value="1" '.checked($value,'1',false).' /> Yes';
        else echo '<input type="text" name="sageus['.esc_attr($name).']" value="'.esc_attr($value).'" placeholder="'.esc_attr($placeholder).'" style="width:100%" />';
        echo '</label></p>';
    }
    public static function render_cover($post) {
        $cover_id = sageus_get_cover_id($post->ID);
        $cover_url = $cover_id ? wp_get_attachment_image_url($cover_id, 'medium') : '';
        echo '<div id="sageus-cover-wrap">';
        if ($cover_url) echo '<img id="sageus-cover-preview" src="'.esc_url($cover_url).'" style="width:100%;height:auto;border-radius:6px;margin-bottom:10px" />';
        else echo '<img id="sageus-cover-preview" src="" style="display:none;width:100%;height:auto;border-radius:6px;margin-bottom:10px" /><p class="description">No cover set yet.</p>';
        echo '<input type="hidden" id="sageus-cover-id" name="sageus[cover_id]" value="'.esc_attr($cover_id).'" />';
        echo '<p><button type="button" class="button button-primary" id="sageus-set-cover">Set Cover Image — Media Library</button> ';
        echo '<button type="button" class="button" id="sageus-remove-cover">Remove</button></p>';
        echo '<p class="description">Opens the Media Library. Pick an existing image or upload a new cover. This also sets the Featured Image, so grids & widgets use the same cover.</p>';
        echo '<p class="description">Still see “Set featured image” not working? Use this button instead — it uses the same Media Library but does not depend on your theme.</p>';
        echo '</div>';
    }
    public static function render_summary($post) {
        $pub = sageus_format_pub_date($post->ID);
        $genres = get_the_terms($post->ID, 'sageus_genre');
        $tags = get_the_terms($post->ID, 'sageus_tag');
        $series = get_the_terms($post->ID, 'sageus_series');
        echo '<table class="sageus-summary-table" style="width:100%">';
        echo '<tr><th style="text-align:left;padding:4px 0">Published</th><td style="padding:4px 0">'.esc_html($pub ?: '— Not set —').' <span class="description"><br>Set in Book Details → Publication Date</span></td></tr>';
        echo '<tr><th style="text-align:left;padding:4px 0;vertical-align:top">Genres</th><td style="padding:4px 0">';
        if ($genres && !is_wp_error($genres)) { foreach ($genres as $t) echo '<span class="sageus-pill">'.esc_html($t->name).'</span> '; } else echo '— None —';
        echo '<br><span class="description">Use the Genres box in the sidebar (or Book Details) to assign.</span></td></tr>';
        echo '<tr><th style="text-align:left;padding:4px 0;vertical-align:top">Tags</th><td style="padding:4px 0">';
        if ($tags && !is_wp_error($tags)) { foreach ($tags as $t) echo '<span class="sageus-pill">'.esc_html($t->name).'</span> '; } else echo '— None —';
        echo '<br><span class="description">Use the Tags box in the sidebar to assign.</span></td></tr>';
        if ($series && !is_wp_error($series)) echo '<tr><th style="text-align:left;padding:4px 0">Series</th><td>'.esc_html($series[0]->name).'</td></tr>';
        echo '</table>';
        echo '<p><a href="'.esc_url(get_permalink($post->ID)).'" target="_blank">View book page →</a> &nbsp; <span class="description">Front-end shows the same box.</span></p>';
    }
    public static function render_details($post) {
        wp_nonce_field('sageus_save','sageus_nonce');
        $g = fn($k)=> sageus_get_book_meta($post->ID,$k,'');
        echo '<div class="sageus-meta-grid">';
        self::field('Author(s)', 'author', $g('author'), 'text','e.g. Jane Doe');
        self::field('Tagline / Short Blurb','tagline',$g('tagline'),'textarea');
        self::field('Publication Date','pub_date',$g('pub_date'),'date');
        self::field('ISBN-13','isbn13',$g('isbn13'),'text','978-...');
        self::field('ISBN-10','isbn10',$g('isbn10'));
        self::field('Publisher','publisher',$g('publisher'));
        self::field('Language','language',$g('language') ?: 'English');
        self::field('Page Count','page_count',$g('page_count'),'number');
        self::field('Position in Series (number)','series_position',$g('series_position'),'number');
        self::field('Formats (comma separated)','formats',$g('formats'),'text','eBook, Paperback, Audiobook');
        self::field('Sample / Preview URL','sample_url',$g('sample_url'));
        self::field('Goodreads URL','goodreads_url',$g('goodreads_url'));
        self::field('BookBub URL','bookbub_url',$g('bookbub_url'));
        self::field('Awards','awards',$g('awards'),'textarea');
        echo '</div>';
        echo '<p><label><strong>Status</strong><br><select name="sageus[status]" style="width:100%">';
        foreach (['available'=>'Available Now','coming_soon'=>'Coming Soon','unpublished'=>'Unpublished','out_of_print'=>'Out of Print'] as $k=>$v) {
            echo '<option value="'.esc_attr($k).'" '.selected($g('status') ?: 'available',$k,false).'>'.esc_html($v).'</option>';
        }
        echo '</select></label></p>';
        self::field('Featured Book?','featured',$g('featured'),'checkbox');
        echo '<p><label><strong>Excerpt (shown on book page)</strong><br><textarea name="sageus[excerpt_text]" rows="6" style="width:100%">'.esc_textarea($g('excerpt_text')).'</textarea></label></p>';
        echo '<p class="description">Tip: Use the main editor above for the full description. Leave any field blank and it simply won’t show on the book page.</p>';
    }
    public static function render_buy($post) {
        $links = sageus_get_buy_links($post->ID);
        $retailers = Sageus_Retailers::get_all();
        // FIX: Always render at least one row, with a data-template for JS cloning (no fragile clone-of-first-row).
        echo '<p class="description">Choose a retailer, paste the purchase URL (affiliate links OK — stored exactly as pasted), add an optional label/format, then click <strong>Update / Publish</strong>. Links appear on the book page under “Available at”.</p>';
        echo '<div id="sageus-buy-repeater">';
        if (empty($links)) $links = [['retailer'=>'','url'=>'','label'=>'','format'=>'']];
        foreach ($links as $i=>$l) {
            echo '<div class="sageus-buy-row" data-index="'.esc_attr($i).'" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;flex-wrap:wrap">';
            echo '<select name="sageus_buy['.$i.'][retailer]" style="flex:1;min-width:140px"><option value="">— Select Retailer —</option>';
            foreach ($retailers as $slug=>$r) echo '<option value="'.esc_attr($slug).'" '.selected($l['retailer'],$slug,false).'>'.esc_html($r['name']).'</option>';
            echo '</select>';
            echo '<input type="url" name="sageus_buy['.$i.'][url]" value="'.esc_attr($l['url']).'" placeholder="https://… (affiliate link OK)" style="flex:2;min-width:200px" />';
            echo '<input type="text" name="sageus_buy['.$i.'][label]" value="'.esc_attr($l['label']).'" placeholder="Label (optional)" style="flex:1;min-width:110px" />';
            echo '<input type="text" name="sageus_buy['.$i.'][format]" value="'.esc_attr($l['format']).'" placeholder="eBook / Paperback" style="flex:1;min-width:110px" />';
            echo '<button type="button" class="button sageus-remove-buy" title="Remove this link">×</button></div>';
        }
        echo '</div>';
        // Hidden template for JS — retailer options are rendered server-side so new rows always have the full list.
        echo '<template id="sageus-buy-template"><div class="sageus-buy-row" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;flex-wrap:wrap">';
        echo '<select name="sageus_buy[__INDEX__][retailer]" style="flex:1;min-width:140px"><option value="">— Select Retailer —</option>';
        foreach ($retailers as $slug=>$r) echo '<option value="'.esc_attr($slug).'">'.esc_html($r['name']).'</option>';
        echo '</select>';
        echo '<input type="url" name="sageus_buy[__INDEX__][url]" value="" placeholder="https://… (affiliate link OK)" style="flex:2;min-width:200px" />';
        echo '<input type="text" name="sageus_buy[__INDEX__][label]" value="" placeholder="Label (optional)" style="flex:1;min-width:110px" />';
        echo '<input type="text" name="sageus_buy[__INDEX__][format]" value="" placeholder="eBook / Paperback" style="flex:1;min-width:110px" />';
        echo '<button type="button" class="button sageus-remove-buy">×</button></div></template>';
        echo '<button type="button" class="button" id="sageus-add-buy">+ Add Another Retailer Link</button>';
        echo '<p class="description">No retailers listed? <a href="'.esc_url(admin_url('edit.php?post_type=sageus_book&page=sageus-retailers')).'">Add retailers here →</a> — then come back and they’ll appear in the dropdown.</p>';
        if (empty($retailers)) echo '<p style="color:#b32d2e"><strong>No retailers found.</strong> Add one on the Retailers page first.</p>';
    }
    public static function render_reviews($post) {
        $reviews = sageus_get_reviews($post->ID);
        if (empty($reviews)) $reviews = [['quote'=>'','reviewer'=>'','source'=>'','rating'=>'','link'=>'']];
        echo '<div id="sageus-reviews-repeater">';
        foreach ($reviews as $i=>$r) {
            echo '<div class="sageus-review-row" style="border:1px solid #ddd;padding:10px;margin-bottom:10px">';
            echo '<p><textarea name="sageus_reviews['.$i.'][quote]" rows="3" style="width:100%" placeholder="Review quote">'.esc_textarea($r['quote']??'').'</textarea></p>';
            echo '<div style="display:flex;gap:8px"><input type="text" name="sageus_reviews['.$i.'][reviewer]" value="'.esc_attr($r['reviewer']??'').'" placeholder="Reviewer" style="flex:1" />';
            echo '<input type="text" name="sageus_reviews['.$i.'][source]" value="'.esc_attr($r['source']??'').'" placeholder="Source / Publication" style="flex:1" />';
            echo '<select name="sageus_reviews['.$i.'][rating]"><option value="">No stars</option>'; for($s=1;$s<=5;$s++) echo '<option value="'.$s.'" '.selected($r['rating']??'',$s,false).'>'.$s.' ★</option>'; echo '</select>';
            echo '<input type="url" name="sageus_reviews['.$i.'][link]" value="'.esc_attr($r['link']??'').'" placeholder="Link to review" style="flex:1" />';
            echo '<button type="button" class="button sageus-remove-review">×</button></div></div>';
        }
        echo '</div><button type="button" class="button" id="sageus-add-review">+ Add Review</button>';
    }
    public static function render_grid($post) {
        wp_nonce_field('sageus_save_grid','sageus_grid_nonce');
        $s = fn($k,$d='')=> get_post_meta($post->ID,'_sageus_grid_'.$k,true) ?: $d;
        $selections = ['all'=>'All Books','available'=>'Available Now','coming_soon'=>'Coming Soon','unpublished'=>'Unpublished Books','genre'=>'Books in a Genre','series'=>'Books in a Series','tag'=>'Books with a Tag','specific'=>'Specific Books (choose below)','featured'=>'Featured Books Only'];
        echo '<p><label><strong>Book Selection</strong><br><select name="sageus_grid[selection]" id="sageus-grid-selection" style="width:100%">';
        foreach ($selections as $k=>$v) echo '<option value="'.esc_attr($k).'" '.selected($s('selection','all'),$k,false).'>'.esc_html($v).'</option>';
        echo '</select></label></p>';
        // Genre / Series / Tag pickers
        foreach (['genre'=>'sageus_genre','series'=>'sageus_series','tag'=>'sageus_tag'] as $key=>$tax) {
            $terms = get_terms(['taxonomy'=>$tax,'hide_empty'=>false]);
            echo '<p class="sageus-grid-tax sageus-grid-tax-'.$key.'" style="display:none"><label><strong>Choose '.ucfirst($key).'</strong><br><select name="sageus_grid[tax_'.$key.'][]" multiple style="width:100%;height:100px">';
            $sel = (array) get_post_meta($post->ID,'_sageus_grid_tax_'.$key,true);
            foreach ($terms as $t) echo '<option value="'.esc_attr($t->term_id).'" '.selected(in_array($t->term_id,$sel),true,false).'>'.esc_html($t->name).'</option>';
            echo '</select></label></p>';
        }
        $books = get_posts(['post_type'=>'sageus_book','posts_per_page'=>-1,'orderby'=>'title','order'=>'ASC']);
        echo '<p class="sageus-grid-specific" style="display:none"><label><strong>Choose Specific Books</strong><br><select name="sageus_grid[specific][]" multiple style="width:100%;height:150px">';
        $sel = (array) get_post_meta($post->ID,'_sageus_grid_specific',true);
        foreach ($books as $b) echo '<option value="'.esc_attr($b->ID).'" '.selected(in_array($b->ID,$sel),true,false).'>'.esc_html($b->post_title).'</option>';
        echo '</select></label></p>';
        echo '<p><label><strong>Grouping</strong><br><select name="sageus_grid[grouping]" style="width:100%">';
        foreach (['none'=>'No Grouping','genre'=>'Group by Genre','series'=>'Group by Series','tag'=>'Group by Tag','status'=>'Group by Status'] as $k=>$v) echo '<option value="'.esc_attr($k).'" '.selected($s('grouping','none'),$k,false).'>'.esc_html($v).'</option>';
        echo '</select></label></p>';
        echo '<p><label><strong>Sort Order</strong><br><select name="sageus_grid[sort]" style="width:100%">';
        foreach (['pub_date_desc'=>'Publication Date — Newest First','pub_date_asc'=>'Publication Date — Oldest First','title_asc'=>'Title A–Z','title_desc'=>'Title Z–A','series_order'=>'Series Order','date_added_desc'=>'Date Added — Newest','date_added_asc'=>'Date Added — Oldest','menu_order'=>'Menu Order','random'=>'Random'] as $k=>$v) echo '<option value="'.esc_attr($k).'" '.selected($s('sort','pub_date_desc'),$k,false).'>'.esc_html($v).'</option>';
        echo '</select></label></p>';
        echo '<p><label><strong>Columns</strong> <input type="number" name="sageus_grid[cols]" value="'.esc_attr($s('cols','3')).'" min="1" max="6" style="width:70px" /></label> &nbsp; <label><strong>Limit</strong> <input type="number" name="sageus_grid[limit]" value="'.esc_attr($s('limit','0')).'" min="0" style="width:70px" /> (0 = all)</label></p>';
        echo '<p><label><strong>Empty State Message</strong><br><input type="text" name="sageus_grid[empty]" value="'.esc_attr($s('empty','More books coming soon.')).'" style="width:100%" /></label></p>';
        echo '<p class="description">Grids auto-update when you add, edit, or remove books. Set it and forget it.</p>';
    }
    public static function render_grid_shortcode($post) {
        if ($post->post_status === 'auto-draft') { echo '<p>Save the grid to get its shortcode.</p>'; return; }
        $code = '[sageus_grid id="'.$post->ID.'"]';
        echo '<p><input type="text" readonly value="'.esc_attr($code).'" onclick="this.select()" style="width:100%" /></p><p class="description">Copy this shortcode and paste it into any page, post, or text widget.</p>';
        echo '<p>Block: Add the “Sageus Book Grid” block and pick this grid.</p>';
    }
    public static function save($post_id, $post) {
        // Don't save on autosave / revision / trash
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
        if ($post->post_type !== 'sageus_book') return;
        // Nonce: meta boxes share one nonce in Book Details. If it's missing (e.g. Quick Edit / REST), don't wipe data.
        $has_nonce = isset($_POST['sageus_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sageus_nonce'])), 'sageus_save');
        $is_quick_edit = isset($_POST['_inline_edit']);
        if (!$has_nonce && !$is_quick_edit) {
            // If this is a REST/Gutenberg save, meta is handled via register_post_meta. Don't clear buy links.
            return;
        }
        if ($is_quick_edit) return; // Quick Edit doesn't include our fields — never wipe them.
        if (!current_user_can('edit_post', $post_id)) return;
        $raw = isset($_POST['sageus']) ? wp_unslash($_POST['sageus']) : [];
        $data = [];
        if (is_array($raw)) foreach ($raw as $k=>$v) $data[$k] = is_array($v) ? $v : sanitize_textarea_field($v);
        $fields = ['author','tagline','pub_date','isbn13','isbn10','publisher','language','page_count','series_position','formats','sample_url','goodreads_url','bookbub_url','awards','status','excerpt_text','cover_id','cover_url'];
        foreach ($fields as $f) {
            $v = $data[$f] ?? '';
            if (in_array($f, ['sample_url','goodreads_url','bookbub_url','cover_url'])) $v = esc_url_raw($v);
            if ($f==='pub_date') $v = sanitize_text_field($v);
            if ($f==='cover_id') $v = (int) $v;
            update_post_meta($post_id, '_sageus_'.$f, $v);
        }
        update_post_meta($post_id, '_sageus_featured', isset($raw['featured']) ? '1' : '0');
        // FIX: Sync Cover box -> Featured Image, and vice versa. If user set cover via our box, set it as thumbnail.
        $cover_id = (int) ($data['cover_id'] ?? 0);
        if ($cover_id) {
            set_post_thumbnail($post_id, $cover_id);
        } elseif (has_post_thumbnail($post_id)) {
            // Featured Image was set via WP box — mirror it into our cover_id so front-end always finds it.
            update_post_meta($post_id, '_sageus_cover_id', (int) get_post_thumbnail_id($post_id));
        }
        // FIX: Buy links — only overwrite when the repeater was actually submitted.
        // Previously, a save without sageus_buy in $_POST (e.g. autosave / quick edit) could wipe links.
        if (isset($_POST['sageus_buy']) && is_array($_POST['sageus_buy'])) {
            $buy = [];
            foreach (wp_unslash($_POST['sageus_buy']) as $row) {
                if (!is_array($row) || empty($row['url'])) continue;
                $buy[] = ['retailer'=>sanitize_text_field($row['retailer']??''),'url'=>esc_url_raw(trim($row['url']??'')),'label'=>sanitize_text_field($row['label']??''),'format'=>sanitize_text_field($row['format']??'')];
            }
            update_post_meta($post_id, '_sageus_buy_links', $buy);
        }
        // Reviews — same guard
        if (isset($_POST['sageus_reviews']) && is_array($_POST['sageus_reviews'])) {
            $reviews = [];
            foreach (wp_unslash($_POST['sageus_reviews']) as $row) {
                if (!is_array($row) || empty($row['quote'])) continue;
                $reviews[] = ['quote'=>sanitize_textarea_field($row['quote']??''),'reviewer'=>sanitize_text_field($row['reviewer']??''),'source'=>sanitize_text_field($row['source']??''),'rating'=>sanitize_text_field($row['rating']??''),'link'=>esc_url_raw($row['link']??'')];
            }
            update_post_meta($post_id, '_sageus_reviews', $reviews);
        }
        delete_transient('sageus_grids_cache');
    }
    public static function save_grid($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!isset($_POST['sageus_grid_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sageus_grid_nonce'])), 'sageus_save_grid')) return;
        if (!current_user_can('edit_post', $post_id)) return;
        $g = isset($_POST['sageus_grid']) ? wp_unslash($_POST['sageus_grid']) : [];
        foreach (['selection','grouping','sort','cols','limit','empty'] as $k) {
            update_post_meta($post_id, '_sageus_grid_'.$k, sanitize_text_field($g[$k] ?? ''));
        }
        foreach (['genre','series','tag'] as $tax) {
            $vals = $g['tax_'.$tax] ?? [];
            update_post_meta($post_id, '_sageus_grid_tax_'.$tax, array_map('intval', (array)$vals));
        }
        $spec = $g['specific'] ?? [];
        update_post_meta($post_id, '_sageus_grid_specific', array_map('intval', (array)$spec));
    }
}
