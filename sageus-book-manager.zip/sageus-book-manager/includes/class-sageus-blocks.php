<?php
if (!defined('ABSPATH')) exit;
class Sageus_Blocks {
    public static function init(){ add_action('init', [__CLASS__,'register']); }
    public static function register(){
        if (!function_exists('register_block_type')) return;
        register_block_type('sageus/book-grid', [
            'attributes'=>['gridId'=>['type'=>'number','default'=>0],'cols'=>['type'=>'number','default'=>3]],
            'render_callback'=>function($atts){
                $id = (int)($atts['gridId'] ?? 0); if (!$id) return '<p>'.esc_html__('Choose a Book Grid in the block settings.','sageus-book-manager').'</p>';
                return Sageus_Grids::render_grid($id, ['cols'=> (int)($atts['cols']??3)]);
            },
        ]);
        // Editor assets: lightweight inline script for the block picker is registered via block.json alternative in JS file
        wp_register_script('sageus-block-editor', SAGEUS_URL.'assets/js/block.js', ['wp-blocks','wp-element','wp-components','wp-editor','wp-data'], SAGEUS_VERSION, true);
        // Note: block editor JS is optional — the block renders server-side and can be inserted via shortcode if JS is not loaded.
    }
}
