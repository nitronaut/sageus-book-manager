<?php
if (!defined('ABSPATH')) exit;
class Sageus_Shortcodes {
    public static function init() {
        add_shortcode('sageus_grid', [__CLASS__,'grid']);
        add_shortcode('sageus_book', [__CLASS__,'book']);
        add_shortcode('sageus_buy', [__CLASS__,'buy']);
    }
    public static function grid($atts) {
        $atts = shortcode_atts(['id'=>0,'cols'=>'','limit'=>''], $atts, 'sageus_grid');
        $id = (int)$atts['id']; if (!$id) return '';
        $args = [];
        if ($atts['cols']!=='') $args['cols']=(int)$atts['cols'];
        if ($atts['limit']!=='') $args['limit']=(int)$atts['limit'];
        return Sageus_Grids::render_grid($id, $args);
    }
    public static function book($atts) {
        $atts = shortcode_atts(['id'=>0,'show'=>'cover,title,author,buy'], $atts, 'sageus_book');
        $id = (int)$atts['id']; if (!$id) return '';
        $show = array_map('trim', explode(',', $atts['show']));
        $out = '<div class="sageus-single-shortcode"><a href="'.esc_url(get_permalink($id)).'">';
        if (in_array('cover',$show)) { $c=sageus_get_cover_url($id,'medium'); if($c) $out.='<img src="'.esc_url($c).'" alt="'.esc_attr(get_the_title($id)).'" class="sageus-shortcode-cover" />'; }
        if (in_array('title',$show)) $out.='<h3>'.esc_html(get_the_title($id)).'</h3>';
        if (in_array('author',$show)) $out.='<p>'.esc_html(sageus_get_book_meta($id,'author','')).'</p>';
        $out.='</a>';
        if (in_array('buy',$show)) $out.= sageus_render_buy_buttons($id);
        $out.='</div>';
        return $out;
    }
    public static function buy($atts) {
        $atts = shortcode_atts(['id'=>0], $atts, 'sageus_buy');
        $id = (int)$atts['id']; if (!$id) return '';
        return sageus_render_buy_buttons($id);
    }
}
