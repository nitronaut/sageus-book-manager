<?php
if (!defined('ABSPATH')) exit;
class Sageus_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct('sageus_book_widget', __('Sageus Book Manager — Book Widget','sageus-book-manager'), ['description'=>__('Feature a book: Random, Newest, Coming Soon, or a Specific book.','sageus-book-manager')]);
    }
    public function widget($args, $instance) {
        $mode = $instance['mode'] ?? 'newest';
        $book_id = 0;
        if ($mode==='random') $book_id = sageus_get_random_book_id();
        elseif ($mode==='future') $book_id = sageus_get_future_book_id();
        elseif ($mode==='specific') $book_id = (int)($instance['book_id'] ?? 0);
        else $book_id = sageus_get_newest_book_id();
        if (!$book_id) return;
        echo $args['before_widget'];
        if (!empty($instance['title'])) echo $args['before_title'].apply_filters('widget_title',$instance['title']).$args['after_title'];
        echo '<div class="sageus-widget-book"><a href="'.esc_url(get_permalink($book_id)).'">';
        $cover = sageus_get_cover_url($book_id,'medium');
        if ($cover) echo '<img src="'.esc_url($cover).'" alt="'.esc_attr(get_the_title($book_id)).'" class="sageus-widget-cover" loading="lazy" />';
        echo '<h4 class="sageus-widget-title">'.esc_html(get_the_title($book_id)).'</h4>';
        $author = sageus_get_book_meta($book_id,'author','');
        if ($author && !empty($instance['show_author'])) echo '<p class="sageus-widget-author">'.esc_html($author).'</p>';
        $pub = sageus_format_pub_date($book_id);
        if ($pub && !empty($instance['show_date'])) echo '<p class="sageus-widget-date">'.esc_html($pub).'</p>';
        echo '</a>';
        if (!empty($instance['show_buy'])) echo sageus_render_buy_buttons($book_id);
        else echo '<a class="sageus-widget-view" href="'.esc_url(get_permalink($book_id)).'">'.esc_html__('View Book →','sageus-book-manager').'</a>';
        echo '</div>';
        echo $args['after_widget'];
    }
    public function form($instance) {
        $title = $instance['title'] ?? __('Featured Book','sageus-book-manager');
        $mode = $instance['mode'] ?? 'newest';
        $book_id = $instance['book_id'] ?? 0;
        echo '<p><label>Title <input class="widefat" name="'.$this->get_field_name('title').'" value="'.esc_attr($title).'" /></label></p>';
        echo '<p><label>Mode <select class="widefat" name="'.$this->get_field_name('mode').'">';
        foreach (['random'=>'Random','newest'=>'Newest','future'=>'Coming Soon (Future)','specific'=>'Specific Book'] as $k=>$v) echo '<option value="'.esc_attr($k).'" '.selected($mode,$k,false).'>'.esc_html($v).'</option>';
        echo '</select></label></p>';
        echo '<p><label>Specific Book <select class="widefat" name="'.$this->get_field_name('book_id').'"><option value="0">—</option>';
        foreach (get_posts(['post_type'=>'sageus_book','posts_per_page'=>-1,'orderby'=>'title','order'=>'ASC']) as $b) echo '<option value="'.esc_attr($b->ID).'" '.selected($book_id,$b->ID,false).'>'.esc_html($b->post_title).'</option>';
        echo '</select></label></p>';
        echo '<p><label><input type="checkbox" name="'.$this->get_field_name('show_author').'" value="1" '.checked($instance['show_author']??1,1,false).' /> Show author</label><br>';
        echo '<label><input type="checkbox" name="'.$this->get_field_name('show_date').'" value="1" '.checked($instance['show_date']??1,1,false).' /> Show publication date</label><br>';
        echo '<label><input type="checkbox" name="'.$this->get_field_name('show_buy').'" value="1" '.checked($instance['show_buy']??0,1,false).' /> Show Buy buttons instead of View link</label></p>';
    }
    public function update($new, $old) {
        $out=[]; $out['title']=sanitize_text_field($new['title']??''); $out['mode']=sanitize_text_field($new['mode']??'newest'); $out['book_id']=(int)($new['book_id']??0);
        $out['show_author']=!empty($new['show_author'])?1:0; $out['show_date']=!empty($new['show_date'])?1:0; $out['show_buy']=!empty($new['show_buy'])?1:0;
        return $out;
    }
    public static function init(){ add_action('widgets_init', fn()=> register_widget(__CLASS__)); }
}
