<?php
if (!defined('ABSPATH')) exit;

function sageus_get_book_meta($post_id, $key, $default = '') {
    $v = get_post_meta($post_id, '_sageus_' . $key, true);
    return $v === '' ? $default : $v;
}
function sageus_get_book_id($id_or_post = null) {
    if ($id_or_post instanceof WP_Post) return $id_or_post->ID;
    if (is_numeric($id_or_post)) return (int) $id_or_post;
    if (is_singular('sageus_book')) return get_the_ID();
    return 0;
}
function sageus_get_pub_date($post_id) {
    return sageus_get_book_meta($post_id, 'pub_date', '');
}
function sageus_get_pub_timestamp($post_id) {
    $d = sageus_get_pub_date($post_id);
    if (!$d) return 0;
    $t = strtotime($d . ' 00:00:00');
    return $t ? $t : 0;
}
function sageus_book_status($post_id) {
    $s = sageus_get_book_meta($post_id, 'status', '');
    if ($s) return $s;
    $ts = sageus_get_pub_timestamp($post_id);
    if ($ts && $ts > current_time('timestamp')) return 'coming_soon';
    if ($ts) return 'available';
    return 'available';
}
function sageus_get_series_position($post_id) {
    return (int) sageus_get_book_meta($post_id, 'series_position', 0);
}
function sageus_get_buy_links($post_id) {
    $links = get_post_meta($post_id, '_sageus_buy_links', true);
    if (!is_array($links)) return [];
    $out = [];
    foreach ($links as $l) {
        if (empty($l['url'])) continue;
        $out[] = [
            'retailer' => sanitize_text_field($l['retailer'] ?? ''),
            'url'      => esc_url_raw($l['url']),
            'label'    => sanitize_text_field($l['label'] ?? ''),
            'format'   => sanitize_text_field($l['format'] ?? ''),
        ];
    }
    return $out;
}
function sageus_get_reviews($post_id) {
    $r = get_post_meta($post_id, '_sageus_reviews', true);
    return is_array($r) ? $r : [];
}
function sageus_get_average_rating($post_id) {
    $reviews = sageus_get_reviews($post_id);
    $sum = 0; $count = 0;
    foreach ($reviews as $rev) {
        if (!empty($rev['rating'])) { $sum += (float)$rev['rating']; $count++; }
    }
    return $count ? round($sum / $count, 1) : 0;
}
function sageus_format_pub_date($post_id) {
    $d = sageus_get_pub_date($post_id);
    if (!$d) return '';
    $fmt = get_option('date_format', 'F j, Y');
    return date_i18n($fmt, strtotime($d));
}
function sageus_get_cover_url($post_id, $size = 'medium_large') {
    // 1) Dedicated Cover box (new, most reliable) — stored as attachment ID
    $cover_id = (int) sageus_get_book_meta($post_id, 'cover_id', 0);
    if ($cover_id) {
        $u = wp_get_attachment_image_url($cover_id, $size);
        if ($u) return $u;
    }
    // 2) Featured Image (WordPress standard)
    if (has_post_thumbnail($post_id)) {
        $u = get_the_post_thumbnail_url($post_id, $size);
        if ($u) return $u;
    }
    // 3) Legacy URL field
    $cover = sageus_get_book_meta($post_id, 'cover_url', '');
    return $cover ? esc_url($cover) : '';
}
function sageus_get_cover_id($post_id) {
    $cid = (int) sageus_get_book_meta($post_id, 'cover_id', 0);
    if ($cid) return $cid;
    if (has_post_thumbnail($post_id)) return (int) get_post_thumbnail_id($post_id);
    return 0;
}
function sageus_get_books_query_args($selection = 'all', $selection_value = '', $sort = 'pub_date_desc', $limit = -1) {
    $args = [
        'post_type' => 'sageus_book',
        'post_status' => 'publish',
        'posts_per_page' => $limit,
        'meta_query' => [],
        'tax_query' => [],
        'orderby' => 'date',
        'order' => 'DESC',
    ];
    $today = date('Y-m-d', current_time('timestamp'));
    switch ($selection) {
        case 'coming_soon':
            $args['meta_query'][] = ['key'=>'_sageus_pub_date','value'=>$today,'compare'=>'>','type'=>'DATE'];
            break;
        case 'available':
            $args['meta_query'][] = [
                'relation'=>'OR',
                ['key'=>'_sageus_pub_date','value'=>$today,'compare'=>'<=','type'=>'DATE'],
                ['key'=>'_sageus_pub_date','compare'=>'NOT EXISTS'],
            ];
            break;
        case 'unpublished':
            $args['meta_query'][] = ['key'=>'_sageus_status','value'=>'unpublished','compare'=>'='];
            break;
        case 'genre':
            if ($selection_value) $args['tax_query'][] = ['taxonomy'=>'sageus_genre','field'=>'term_id','terms'=> (array)$selection_value];
            break;
        case 'series':
            if ($selection_value) $args['tax_query'][] = ['taxonomy'=>'sageus_series','field'=>'term_id','terms'=> (array)$selection_value];
            break;
        case 'tag':
            if ($selection_value) $args['tax_query'][] = ['taxonomy'=>'sageus_tag','field'=>'term_id','terms'=> (array)$selection_value];
            break;
        case 'specific':
            if ($selection_value) { $args['post__in'] = array_map('intval',(array)$selection_value); $args['orderby']='post__in'; }
            break;
        case 'featured':
            $args['meta_query'][] = ['key'=>'_sageus_featured','value'=>'1','compare'=>'='];
            break;
    }
    switch ($sort) {
        case 'pub_date_desc': $args['orderby']='meta_value'; $args['meta_key']='_sageus_pub_date'; $args['order']='DESC'; break;
        case 'pub_date_asc': $args['orderby']='meta_value'; $args['meta_key']='_sageus_pub_date'; $args['order']='ASC'; break;
        case 'title_asc': $args['orderby']='title'; $args['order']='ASC'; break;
        case 'title_desc': $args['orderby']='title'; $args['order']='DESC'; break;
        case 'date_added_desc': $args['orderby']='date'; $args['order']='DESC'; break;
        case 'date_added_asc': $args['orderby']='date'; $args['order']='ASC'; break;
        case 'series_order': $args['orderby']='meta_value_num'; $args['meta_key']='_sageus_series_position'; $args['order']='ASC'; break;
        case 'menu_order': $args['orderby']='menu_order title'; $args['order']='ASC'; break;
        case 'random': $args['orderby']='rand'; break;
    }
    return apply_filters('sageus_grid_query_args', $args, $selection, $selection_value, $sort);
}
function sageus_render_stars($rating) {
    if (!$rating) return '';
    $full = floor($rating); $half = ($rating - $full) >= 0.5;
    $out = '<span class="sageus-stars" aria-label="'.esc_attr(sprintf(__('Rated %s out of 5','sageus-book-manager'), $rating)).'">';
    for ($i=1;$i<=5;$i++) {
        if ($i <= $full) $out .= '<span aria-hidden="true">★</span>';
        elseif ($half && $i === $full+1) $out .= '<span aria-hidden="true">⯨</span>';
        else $out .= '<span class="sageus-star-empty" aria-hidden="true">☆</span>';
    }
    $out .= '</span>';
    return $out;
}
function sageus_render_buy_buttons($post_id, $args = []) {
    $links = sageus_get_buy_links($post_id);
    if (empty($links)) return '';
    $retailers = Sageus_Retailers::get_all();
    $new_tab = get_option('sageus_open_new_tab', '1') === '1';
    $out = '<div class="sageus-buy-buttons">';
    $out .= '<p class="sageus-buy-label">'.esc_html__('Available at','sageus-book-manager').'</p>';
    foreach ($links as $link) {
        $ret = $retailers[$link['retailer']] ?? null;
        $name = $ret['name'] ?? $link['retailer'];
        $label = $link['label'] ? $link['label'] : $name;
        if ($link['format']) $label .= ' — ' . $link['format'];
        $style = '';
        if ($ret && !empty($ret['color'])) $style = ' style="background:'.esc_attr($ret['color']).'"';
        $img = '';
        if ($ret && !empty($ret['image'])) $img = '<img src="'.esc_url($ret['image']).'" alt="" class="sageus-retailer-icon" />';
        $out .= '<a class="sageus-buy-btn" href="'.esc_url($link['url']).'"'.($new_tab ? ' target="_blank" rel="sponsored noopener"' : ' rel="sponsored"').$style.'>'.$img.'<span>'.esc_html($label).'</span></a>';
    }
    $out .= '</div>';
    $disc = get_option('sageus_affiliate_disclosure', '');
    if ($disc) $out .= '<p class="sageus-disclosure"><small>'.esc_html($disc).'</small></p>';
    return $out;
}
function sageus_get_newest_book_id() {
    $today = date('Y-m-d', current_time('timestamp'));
    $q = new WP_Query([
        'post_type'=>'sageus_book','post_status'=>'publish','posts_per_page'=>1,
        'meta_query'=>[['key'=>'_sageus_pub_date','value'=>$today,'compare'=>'<=','type'=>'DATE']],
        'orderby'=>'meta_value','meta_key'=>'_sageus_pub_date','order'=>'DESC',
    ]);
    return $q->have_posts() ? $q->posts[0]->ID : 0;
}
function sageus_get_future_book_id() {
    $today = date('Y-m-d', current_time('timestamp'));
    $q = new WP_Query([
        'post_type'=>'sageus_book','post_status'=>'publish','posts_per_page'=>1,
        'meta_query'=>[['key'=>'_sageus_pub_date','value'=>$today,'compare'=>'>','type'=>'DATE']],
        'orderby'=>'meta_value','meta_key'=>'_sageus_pub_date','order'=>'ASC',
    ]);
    if ($q->have_posts()) return $q->posts[0]->ID;
    // Fallback: undated books, earliest added
    $q2 = new WP_Query([
        'post_type'=>'sageus_book','post_status'=>'publish','posts_per_page'=>1,
        'meta_query'=>[['key'=>'_sageus_pub_date','compare'=>'NOT EXISTS']],
        'orderby'=>'date','order'=>'ASC',
    ]);
    return $q2->have_posts() ? $q2->posts[0]->ID : sageus_get_newest_book_id();
}
function sageus_get_random_book_id() {
    $q = new WP_Query(['post_type'=>'sageus_book','post_status'=>'publish','posts_per_page'=>1,'orderby'=>'rand']);
    return $q->have_posts() ? $q->posts[0]->ID : 0;
}
