<?php
if (!defined('ABSPATH')) exit;
class Sageus_CPT {
    public static function init() {
        add_action('init', [__CLASS__, 'register_all']);
        add_action('init', [__CLASS__, 'register_taxonomies']);
        add_filter('manage_sageus_book_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_sageus_book_posts_custom_column', [__CLASS__, 'column_content'], 10, 2);
        add_filter('manage_edit-sageus_book_sortable_columns', [__CLASS__, 'sortable']);
        add_action('pre_get_posts', [__CLASS__, 'admin_order']);
    }
    public static function register_all() {
        self::register_book();
        self::register_grid();
        self::register_taxonomies();
    }
    public static function register_book() {
        $labels = [
            'name'=>'Books','singular_name'=>'Book','menu_name'=>'Books','add_new'=>'Add New','add_new_item'=>'Add New Book',
            'edit_item'=>'Edit Book','new_item'=>'New Book','view_item'=>'View Book','search_items'=>'Search Books',
            'not_found'=>'No books found','not_found_in_trash'=>'No books found in Trash','all_items'=>'All Books',
        ];
        register_post_type('sageus_book', [
            'labels'=>$labels,'public'=>true,'show_ui'=>true,'show_in_menu'=>true,'show_in_rest'=>true,
            'menu_position'=>20,'menu_icon'=>'dashicons-book-alt','supports'=>['title','editor','thumbnail','excerpt','revisions','custom-fields','page-attributes'], // thumbnail = Featured Image
            'has_archive'=>true,'rewrite'=>['slug'=> get_option('sageus_book_slug','books'),'with_front'=>false],
            'capability_type'=>'post','show_in_nav_menus'=>true,
        ]);
    }
    public static function register_grid() {
        $labels = ['name'=>'Book Grids','singular_name'=>'Book Grid','menu_name'=>'Book Grids','add_new'=>'Add New','add_new_item'=>'Add New Book Grid','edit_item'=>'Edit Book Grid','all_items'=>'All Book Grids','not_found'=>'No grids found'];
        register_post_type('sageus_grid', [
            'labels'=>$labels,'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=sageus_book','show_in_rest'=>true,
            'menu_icon'=>'dashicons-grid-view','supports'=>['title'],'capability_type'=>'post',
        ]);
    }
    public static function register_taxonomies() {
        register_taxonomy('sageus_genre', ['sageus_book'], ['labels'=>['name'=>'Genres','singular_name'=>'Genre','add_new_item'=>'Add New Genre'],'hierarchical'=>true,'show_ui'=>true,'show_in_rest'=>true,'show_admin_column'=>true,'rewrite'=>['slug'=>'genre']]);
        register_taxonomy('sageus_series', ['sageus_book'], ['labels'=>['name'=>'Series','singular_name'=>'Series','add_new_item'=>'Add New Series'],'hierarchical'=>true,'show_ui'=>true,'show_in_rest'=>true,'show_admin_column'=>true,'rewrite'=>['slug'=>'series']]);
        register_taxonomy('sageus_tag', ['sageus_book'], ['labels'=>['name'=>'Tags','singular_name'=>'Tag','add_new_item'=>'Add New Tag'],'hierarchical'=>false,'show_ui'=>true,'show_in_rest'=>true,'show_admin_column'=>true,'rewrite'=>['slug'=>'book-tag']]);
    }
    public static function columns($cols) {
        $new = [];
        $new['cb']=$cols['cb']; $new['title']=$cols['title']; $new['cover']='Cover'; $new['author']='Author'; $new['pub_date']='Publication Date'; $new['status']='Status'; $new['series']='Series'; $new['date']=$cols['date'];
        return $new;
    }
    public static function column_content($col, $post_id) {
        if ($col==='cover') { if (has_post_thumbnail($post_id)) echo get_the_post_thumbnail($post_id,[60,80]); else echo '—'; }
        if ($col==='author') echo esc_html(sageus_get_book_meta($post_id,'author',''));
        if ($col==='pub_date') echo esc_html(sageus_format_pub_date($post_id) ?: '—');
        if ($col==='status') echo esc_html(ucwords(str_replace('_',' ', sageus_book_status($post_id))));
        if ($col==='series') { $t=get_the_terms($post_id,'sageus_series'); echo $t && !is_wp_error($t) ? esc_html($t[0]->name) : '—'; }
    }
    public static function sortable($cols){ $cols['pub_date']='pub_date'; return $cols; }
    public static function admin_order($q){ if (is_admin() && $q->is_main_query() && $q->get('orderby')==='pub_date'){ $q->set('meta_key','_sageus_pub_date'); $q->set('orderby','meta_value'); } }
}
